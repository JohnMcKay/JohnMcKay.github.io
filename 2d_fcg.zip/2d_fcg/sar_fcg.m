%% John McKay
% jmckaypitt@gmail.com
% 2D FCG

%% This can be removed if desired
clear all
close all
clc
format long
format compact

%% Precursors 
m = 30; % radius of the spiral
p = 20; % rays of spiral
band = 15;
a = 1e-12;
holdM = 2*m+1;

%% Create 2D Sample and Grid Data
theta=-linspace(-pi/4,pi/4,p)';
argu =repmat(theta,1,m+1,1);
radi =repmat(40:m+40,length(theta),1);
Datx = radi.*cos(argu)-m/2-30;
Daty = radi.*sin(argu);

osam =2; %over sampling rate
Datx =Datx(:)/osam;
Daty =Daty(:)/osam;

jit  =1/16;
Datx =Datx+jit*rand(length(Datx),1);
Daty =Daty+jit*rand(length(Daty),1);

nx   =max(ceil((abs(Datx))));
ny   =max(ceil((abs(Daty))));

%% Construct Grids
Grdx =repmat(-nx:nx,2*ny+1,1);
Grdy =repmat(-(-ny:ny)',1,nx*2+1);
Grdx =Grdx(:);
Grdy =Grdy(:);
% Define M, N
M = length(Datx);
N = length(Grdx);
% Plot data sample
h=figure(10);
axis([-nx-3 nx+3 -ny-3 ny+3]);hold on
scatter(Grdx,Grdy,'ko','linewidth',.8)
scatter(Datx,Daty,'x','linewidth',1);grid on
title('Data Arrangement','fontsize',16,'fontname','avante garde')
set(gca,'fontname','avantegarde','fontsize',16)
hold off
print(h,'sar_data','-dpng')

%%
% psi
ppsi = @(x,y,j) exp(2*1i*pi*(Datx(j)*abs(x)+Daty(j)*abs(y)));
% phi
phi = @(a,x,y) exp(-a*abs(x-.5)-a*abs(y-.5));

% Find fhat (Fourier data)
fhat =zeros(M,1);
for j=1:M
    fhat(j)=quad2d(@(x,y)(conj(ppsi(x,y,j)).*testfun(x,y)),0,1,0,1);
end

%% compute mPsi, mOmega, T
mPsi=zeros(M,N);
mOmega=zeros(N,M);
for j=1:N
    mPsi(:,j)=reciphihat(a, Grdx(j)-Datx,Grdy(j)-Daty)';
    mOmega(j,:)=phihat(a, Grdx(j)-Datx,Grdy(j)-Daty); 
end

T=mPsi*mOmega;
tt=figure(100);
imagesc(abs(T));
title('T Matrix')
print(tt,'tmatrix','-dpng')
% find the coeff with the frame algorithm
tic()
vdfrm=mPsi\fhat; % uniform resampling/Frame Approximation
ftim =toc();

% find a (2k-1)-banded matrix D to minimize |TD-I|_F
Dband=zeros(M);
k=band;
mI=eye(M);
% hSiz=(2*sum(1+r:r+r)+(2*r+1)*(M-2*r));
hBnd=sign(conv2(eye(M),ones(k+1),'same'));
% pinv(T(hBnd==1))
temp =find(hBnd==1);
hInv =zeros(M);
hInv(temp)=T(temp);
tic()
Dband=pinv(hInv);
btim =toc();

%% FCG coefficients
vdband=mOmega*Dband*fhat;

%% graph the recovered functions
sn=80;
xx = linspace(0,1,sn);
yy = linspace(0,1,sn);

xx = repmat(xx,sn,1);
yy = repmat(yy,sn,1)';

xxn = reshape(xx',sn^2,1);
yyn = reshape(kron(linspace(0,1,sn),ones(sn,1)),sn^2,1);
zzn = testfun(xxn,yyn);

zzt =zeros(size(zzn));

F = zeros(sn^2,N);
for j=1:sn^2
    F(j,:)=exp(2i*pi*(Grdx*xxn(j)+Grdy*yyn(j)))/phi(a,xxn(j),yyn(j));
end
yfrm = F*vdfrm;
yband= F*vdband;

yfrm=real(yfrm);
yband=real(yband);

%%
errfrm=norm(zzn-yfrm)/sqrt(sn);
errband=norm(zzn-yband)/sqrt(sn);

set(0,'defaultaxesfontsize',40,'defaulttextfontsize',40');
f=figure(1);
scatter3(xxn,yyn,zzn,'Cdata',zzn)%,'MarkerFaceColor','red')
title('Actual')
axis([0 1 0 1 min(zzn)*1.1 max(zzn)*1.1])
colormap('spring');%colorbar
view([20 200 250])
print(f,'fimg','-dpng')
%
Afr=figure(2);
scatter3(xxn,yyn,yfrm,'Cdata',yfrm)%,'MarkerFaceColor','green')
title('Frame')
axis([0 1 0 1 min(yfrm)*1.1 max(yfrm)*1.1])
colormap('spring');%colorbar
view([20 200 250])
print(Afr,'Afr','-dpng')
%
Afcg=figure(3);
scatter3(xxn,yyn,yband,'Cdata',yband)%,'MarkerFaceColor','magenta')
title('FTCG')
axis([0 1 0 1 min(yband)*1.1 max(yband)*1.1])
colormap('spring');%colorbar
view([20 200 250])
print(Afcg,'Afcg','-dpng')
%
frameError=figure(4);
scatter3(xxn,yyn,log10(abs(zzn-yfrm)),ones(size(xxn,1), 1)*5,log10(abs(zzn-yfrm)))
%colorbar
title('log10 Frame Error ')
print(frameError,'frameError','-dpng')
%
fcgError=figure(5);
scatter3(xxn,yyn,log10(abs(zzn-yband)),ones(size(xxn,1), 1)*5,log10(abs(zzn-yband)))
%colorbar
title('log10 FTCG Error')
print(fcgError,'fcgError','-dpng')

disp('Estimated Error Between CG and Frame')
disp(norm(mOmega*Dband*fhat-vdfrm,2))
%%
zzIm =mat2gray(reshape(zzn,sn,sn));
frIm =mat2gray(reshape(yfrm,sn,sn));
fcIm =mat2gray(reshape(yband,sn,sn));
cp=figure(11);%,'Position',[100 100 800 400]);
subplot(1,3,1)
imagesc(reshape(zzn,sn,sn));axis image;title('Actual');axis off
set(gca,'fontsize',16)
subplot(1,3,2)
imagesc(reshape(yfrm,sn,sn));axis image;title('Frame');axis off
disp('FA PSNR (w/ Respect to Actual)')
disp(psnr(frIm,zzIm))
set(gca,'fontsize',16)
subplot(1,3,3)
imagesc(reshape(yband,sn,sn));axis image;title('FTCG');axis off
disp('FCG PSNR (w/ Respect to Actual)')
disp(psnr(fcIm,zzIm))
set(gca,'fontsize',16)
set(gcf, 'Units', 'Inches', 'Position', ...
  [1, 1, 3, 2], 'PaperUnits', 'Inches', 'PaperSize', [3, 2])
print(cp,'imageRecon','-dpng')





























