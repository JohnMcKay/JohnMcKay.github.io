function z = phihat( a,x,y )
    % Closed form fourier transform of exp(-a|x-.5|)exp(-a|y-.5|)
    a = -a;
    xx = 2*(a*(exp(a/2)*cos(pi*x) - 1) + 2*pi*x*exp(a/2).*sin(pi*x))./(a^2 + 4*pi^2*x.^2) .*exp(-pi*1i*x);
    yy = 2*(a*(exp(a/2)*cos(pi*y) - 1) + 2*pi*y*exp(a/2).*sin(pi*y))./(a^2 + 4*pi^2*y.^2) .*exp(-pi*1i*y);
    %xx = ( exp(-a/2-2*pi*1i*x).*( -a*(-2*exp(a/2+2*pi*1i*x)+exp(2*1i*pi*x)+1 )-2*1i*pi*(exp(2*1i*pi*x)).*x ))./(a^2+4*pi^2*x.^2);
    %yy = ( exp(-a/2-2*pi*1i*y).*( -a*(-2*exp(a/2+2*pi*1i*y)+exp(2*1i*pi*y)+1 )-2*1i*pi*(exp(2*1i*pi*y)).*y ))./(a^2+4*pi^2*y.^2);
    z = xx .* yy;
end

