function z=testfun(x,y)
    x=(x-.5); % make the function symmetric to x,y=0.5
    y=(y-.5);
    z    =sin(4*pi*x).*sin(2*pi*y);	    
    %z = cos(.8*pi*x).*cos(3*pi*y).^2;
    %z    =sin(4*pi*x).*(y.^2-1).^2;
    %z=sin(4*x+4*y);%+3*cos(5*y); 
    %z=sin(x)+cos(y);
end

