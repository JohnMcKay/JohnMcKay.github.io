function z = phi( a,x,y )
    z = exp(-a*abs(x)-a*abs(y));
end

