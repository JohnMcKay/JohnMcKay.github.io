function z = reciphihat( a,x,y )
    xx = 2*(a*(exp(a/2)*cos(pi*x) - 1) + 2*pi*x*exp(a/2).*sin(pi*x))./(a^2 + 4*pi^2*x.^2) .*exp(-pi*1i*x);
    yy = 2*(a*(exp(a/2)*cos(pi*y) - 1) + 2*pi*y*exp(a/2).*sin(pi*y))./(a^2 + 4*pi^2*y.^2) .*exp(-pi*1i*y);
    z = xx .* yy;
end

