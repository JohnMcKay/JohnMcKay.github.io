#############################################
# 2D Frame Theoretic Convolutional Gridding # 
# Written By:  John McKay                   #
# Contact:     John.McKay@psu.edu           #
# This code executes the 2D FTCG algorithm  #
# from the paper:                           #
#     Using Frame Theoretic Convolutional   #
#     Gridding for Robust Synthetic Aperture#
#     Sonar Imaging                         #
#     IEEE/MTS OCEANS 2017 Anchorage        #
#                                           #
# **Thank you to Dr. Guohui Song for his    #
#   help crafting this code. Much comes     #
#   from his original work on 1D FTCG.      #
#############################################

#############################################
# Code Details                              #
# sar_fcg.m                                 #
#     Main (and really only) executable     #
#     file.  This guy creates synthetic     #
#     spotlight-style SAS (or SAR) data     #
#     and then the rest of the code goes    #
#     through with the FA and FTCG methods. #
#     Once can play around with the         #
#     sampling (increase/decrease, change   #
#     angles, etc) as well as the band.     #
# testfun.m                                 #
#     The test function that sar_fcg is     #
#     trying to recover.                    #
# phi.m                                     #
# phihat.m                                  #
# reciphihat.m                              #
#     These play the role of window         #
#     function, frame, etc.  Play around    #
#     with these at your >own< risk. We     #
#     preset these based on Fourier         #
#     transformations and set properties.   #
#############################################

#############################################
# Contact me (John.McKay@psu.edu) if you    #
# find any errors or whatnot.               #
# Use as you will and just cite the paper   #
#############################################










